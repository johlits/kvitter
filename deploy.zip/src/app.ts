import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import usersRouter from './routes/users';
import tweetsRouter from './routes/tweets';
import { isHealthy as dbHealthy } from './db/sqlite';

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());

app.get('/', (_req, res) => {
  res.json({ name: 'kvitter', status: 'ok' });
});

app.get('/health/db', (_req, res) => {
  res.json({ db: dbHealthy() ? 'ok' : 'error' });
});

app.use('/api/users', usersRouter);
app.use('/api/tweets', tweetsRouter);

// Basic error handler
app.use((err: any, _req: express.Request, res: express.Response, _next: express.NextFunction) => {
  console.error('Error:', err);
  res.status(500).json({ error: 'Internal Server Error' });
});

export default app;
